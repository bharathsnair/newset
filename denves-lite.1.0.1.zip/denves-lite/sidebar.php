<?php

	if ( denves_lite_template('span') == 'col-md-8' ) : 

		do_action('denves_lite_side_sidebar');
	 
	endif; 

?>