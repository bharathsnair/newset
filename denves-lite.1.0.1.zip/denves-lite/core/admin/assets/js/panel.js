/*
 * Denves Lite panel javascript file
 * https://www.themeinprogress.com
 *
 * Copyright 2019, ThemeinProgress
 * Licensed under MIT license
 * https://opensource.org/licenses/mit-license.php
 */

jQuery.noConflict()(function($){

	'use strict';

/* ===============================================
   Tabs
   =============================================== */

	$( '#tabs.denves_lite_metaboxes' ).tabs();

});