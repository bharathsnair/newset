<div class="container">
	
    <?php 
	
		do_action('denves_lite_archive_title');
		do_action('denves_lite_masonry');
		do_action('denves_lite_pagination', 'archive');
		
	?>

</div>