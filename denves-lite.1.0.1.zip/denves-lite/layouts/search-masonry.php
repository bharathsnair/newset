<div class="container">
	
    <?php 

		do_action('denves_lite_searched_item');
		do_action('denves_lite_masonry');
		do_action('denves_lite_pagination', 'archive');

	?>

</div>