<div class="container masonry-container">
	
	<?php 
	
		do_action('denves_lite_masonry'); 
		do_action('denves_lite_pagination', 'home'); 
	
	?>

</div>